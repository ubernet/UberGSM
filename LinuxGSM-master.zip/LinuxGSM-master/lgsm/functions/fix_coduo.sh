#!/bin/bash
# LinuxGSM fix_coduo.sh function
# Author: Alexander Hurd
# Website: https://linuxgsm.com
# Description: Fixes for Call of Duty: United Offensive

local commandname="FIX"
local commandaction="Fix"

# Force glibc fix
fix_glibc.sh

